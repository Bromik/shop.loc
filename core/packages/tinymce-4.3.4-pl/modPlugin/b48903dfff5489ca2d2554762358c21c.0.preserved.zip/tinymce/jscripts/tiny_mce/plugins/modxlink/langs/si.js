tinyMCE.addI18n('si.modxlink',{
    link_desc:"Insert/edit link"
});