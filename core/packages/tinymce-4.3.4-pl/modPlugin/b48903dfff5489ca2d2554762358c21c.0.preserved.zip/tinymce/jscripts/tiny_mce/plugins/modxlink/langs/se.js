tinyMCE.addI18n('se.modxlink',{
    link_desc:"Insert/edit link"
});