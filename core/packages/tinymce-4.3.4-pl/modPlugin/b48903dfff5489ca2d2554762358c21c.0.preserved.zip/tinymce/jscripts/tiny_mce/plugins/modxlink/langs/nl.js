tinyMCE.addI18n('nl.modxlink',{
    link_desc:"Insert/edit link"
});