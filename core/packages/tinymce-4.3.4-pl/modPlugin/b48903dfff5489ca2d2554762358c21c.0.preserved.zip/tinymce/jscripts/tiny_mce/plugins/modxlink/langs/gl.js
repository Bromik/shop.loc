tinyMCE.addI18n('gl.modxlink',{
    link_desc:"Insert/edit link"
});