tinyMCE.addI18n({si:{
common:{
edit_confirm:"\u0D94\u0DB6\u0DA7 \u0DB8\u0DD9\u0DB8 \u0DB4\u0DCF\u0DA8\u0DBA\u0DB1\u0DCA \u0DC3\u0DB3\u0DC4\u0DCF WYSIWYG \u0D86\u0D9A\u0DCF\u0DBB\u0DBA?",
apply:"\u0DBA\u0DDC\u0DAF\u0DB1\u0DCA\u0DB1",
insert:"\u0D87\u0DAD\u0DD4\u0DC5\u0DAD\u0DCA \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1",
update:"\u0D85\u0DBD\u0DD4\u0DAD\u0DCA \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1",
cancel:"\u0D85\u0DC0\u0DBD\u0D82\u0D9C\u0DD4 \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1",
close:"\u0D89\u0DC0\u0DAD\u0DCA\u0DC0\u0DB1\u0DCA\u0DB1",
browse:"Browse",
class_name:"\u0DC3\u0DB8\u0DD6\u0DC4\u0DBA",
not_set:"-- Not set --",
clipboard_msg:"\u0DB4\u0DD2\u0DA7\u0DB4\u0DAD\u0DCA \u0D9A\u0DD2\u0DBB\u0DD3\u0DB8/\u0D89\u0DC0\u0DAD\u0DCA \u0D9A\u0DD2\u0DBB\u0DD3\u0DB8/\u0D87\u0DBD\u0DC0\u0DD3\u0DB8 \u0DB8\u0DDC\u0DC3\u0DD2\u0DBD\u0DCA\u0DBD\u0DCF \u0DC4\u0DCF \u0DC6\u0DBA\u0DBB\u0DCA \u0DC6\u0DDC\u0D9A\u0DCA\u0DC3\u0DCA \u0DC4\u0DD2 \u0D87\u0DAD\u0DD4\u0DC5\u0DAD\u0DCA \u0DB1\u0DDC\u0DC0\u0DDA.\n\u0D94\u0DB6\u0DA7 \u0DB8\u0DDA \u0DB4\u0DD2\u0DC5\u0DD2\u0DB6\u0DB3\u0DC0 \u0DAD\u0DA0\u0DAF\u0DD4\u0DBB\u0DA7\u0DAD\u0DCA \u0DAD\u0DDC\u0DBB\u0DAD\u0DD4\u0DBB\u0DD4 \u0D85\u0DC0\u0DC1\u0DCA\u200D\u0DBA \u0DC0\u0DDA\u0DAF?",
clipboard_no_support:"\u0DAF\u0DD0\u0DB1\u0DA7 \u0DB4\u0DCA\u200D\u0DBB\u0DAF\u0DBB\u0DCA\u0DC1\u0D9A\u0DBA \u0DB8\u0D9F\u0DD2\u0DB1\u0DCA \u0DB8\u0DD9\u0DB8 \u0DC3\u0DDA\u0DC0\u0DBA \u0DC3\u0DB4\u0DBA\u0DCF \u0DB1\u0DD0\u0DAD,\u0D91\u0DB6\u0DD0\u0DC0\u0DD2\u0DB1\u0DCA \u0DBA\u0DAD\u0DD4\u0DBB\u0DD4\u0DB4\u0DD4\u0DC0\u0DBB\u0DD4\u0DC0 \u0DB7\u0DCF\u0DC0\u0DD2\u0DAD\u0DCF \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1.",
popup_blocked:"\u0D94\u0DB6\u0D9C\u0DDA popup-blocker \u0DB8\u0D9F\u0DD2\u0DB1\u0DCA \u0D8B\u0DB4\u0DBA\u0DDD\u0D9C\u0DD2 \u0DC3\u0DDA\u0DC0\u0DCF\u0DC0\u0DB1\u0DCA \u0DC3\u0DB4\u0DBA\u0DB1 \u0D9A\u0DC0\u0DD4\u0DBD\u0DD4\u0DC0\u0D9A\u0DCA \u0D85\u0DB6\u0DBD \u0D9A\u0DBB \u0D87\u0DAD.\u0D91\u0DB6\u0DD0\u0DC0\u0DD2\u0DB1\u0DCA \u0D94\u0DB6\u0DA7 popup-blocker \u0DBA \u0D85\u0D9A\u0DCA\u200D\u0DBB\u0DD3\u0DBA \u0D9A\u0DD2\u0DBB\u0DD3\u0DB8\u0DA7 \u0DC3\u0DD2\u0DAF\u0DD4\u0DC0\u0DDA. ",
invalid_data:"\u0DC0\u0DBB\u0DAF: \u0DC0\u0DBD\u0D82\u0D9C\u0DD4 \u0DB1\u0DDC\u0DB8\u0DD0\u0DAD\u0DD2 \u0D85\u0D9C\u0DBA\u0DB1\u0DCA \u0D87\u0DAD\u0DD4\u0DC5\u0DAD\u0DCA \u0D9A\u0DBB \u0D87\u0DAD,\u0D91\u0DB8 \u0D85\u0D9C\u0DBA\u0DB1\u0DCA \u0DBB\u0DAD\u0DD4 \u0DB4\u0DCF\u0DA7\u0DD2\u0DB1\u0DCA \u0DC3\u0DC5\u0D9A\u0DD4\u0DAB\u0DD4 \u0D9A\u0DBB \u0D87\u0DAD.",
more_colors:"\u0DAD\u0DC0\u0DAD\u0DCA \u0DC0\u0DBB\u0DCA\u0DAB"
},
contextmenu:{
align:"\u0DB4\u0DD9\u0DC5 \u0D9C\u0DD0\u0DB1\u0DCA\u0DC0\u0DD4\u0DB8",
left:"\u0DC0\u0DB8\u0DA7",
center:"\u0DB8\u0DD0\u0DAF\u0DA7",
right:"\u0DAF\u0D9A\u0DD4\u0DAB\u0DA7",
full:"\u0DB4\u0DD6\u0DBB\u0DCA\u0DAB\u0DC0"
},
insertdatetime:{
date_fmt:"%\u0D85\u0DC0\u0DD4-%\u0DB8\u0DCF\u0DC3-%\u0DAF\u0DD2\u0DB1",
time_fmt:"%\u0DB4\u0DD0\u0DBA:%\u0DB8\u0DD2\u0DC3:%\u0DAD\u0DAD\u0DCA",
insertdate_desc:"\u0DAF\u0DD2\u0DB1\u0DBA \u0D87\u0DAD\u0DD4\u0DC5\u0DAD\u0DCA \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1",
inserttime_desc:"\u0DC0\u0DDA\u0DBD\u0DCF\u0DC0 \u0D87\u0DAD\u0DD4\u0DC5\u0DAD\u0DCA \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1",
months_long:"\u0DA2\u0DB1\u0DC0\u0DCF\u0DBB\u0DD2,\u0DB4\u0DD9\u0DB6\u0DBB\u0DC0\u0DCF\u0DBB\u0DD2,\u0DB8\u0DCF\u0DBB\u0DCA\u0DAD\u0DD4,\u0D85\u0DB4\u0DCA\u200D\u0DBB\u0DDA\u0DBD\u0DCA,\u0DB8\u0DD0\u0DBA\u0DD2,\u0DA2\u0DD6\u0DB1\u0DD2,\u0DA2\u0DD6\u0DBD\u0DD2,\u0D85\u0D9C\u0DDD\u0DC3\u0DCA\u0DAD\u0DD4,\u0DC3\u0DD0\u0DCA\u0DAD\u0DD0\u0DB8\u0DCA\u0DB6\u0DBB\u0DCA,\u0D94\u0D9A\u0DCA\u0DAD\u0DDD\u0DB6\u0DBB\u0DCA,\u200D\u0DB1\u0DDC\u0DC0\u0DD0\u0DB8\u0DCA\u0DB6\u0DBB\u0DCA,\u0DAF\u0DD9\u0DC3\u0DD0\u0DB8\u0DCA\u0DB6\u0DBB\u0DCA",
months_short:"\u0DA2\u0DB1.,\u0DB4\u0DD9\u0DB6.,\u0DB8\u0DCF\u0DBB\u0DCA\u0DAD\u0DD4,\u0D85\u0DB4\u0DCA\u200D\u0DBB\u0DDA\u0DBD\u0DCA,\u0DB8\u0DD0\u0DBA\u0DD2,\u0DA2\u0DD6\u0DB1\u0DD2,\u0DA2\u0DD6\u0DBD\u0DD2,\u0D85\u0D9C\u0DDD.,\u0DC3\u0DD0\u0DCA.,\u0D94\u0D9A\u0DCA.,\u200D\u0DB1\u0DDC\u0DC0\u0DD0.,\u0DAF\u0DD9\u0DC3\u0DD0.",
day_long:"\u0D89\u0DBB\u0DD2\u0DAF\u0DCF,\u0DC3\u0DB3\u0DD4\u0DAF\u0DCF,\u0D85\u0D9F\u0DC4\u0DBB\u0DD0\u0DC0\u0DCF\u0DAF\u0DCF,\u0DB6\u0DAF\u0DCF\u0DAF\u0DCF,\u0DB6\u0DCA\u200D\u0DBB\u0DC4\u0DC3\u0DCA\u0DB4\u0DAD\u0DD2\u0DB1\u0DCA\u0DAF\u0DCF,\u0DC3\u0DD2\u0D9A\u0DD4\u0DBB\u0DCF\u0DAF\u0DCF,\u0DC3\u0DD9\u0DB1\u0DC3\u0DD4\u0DBB\u0DCF\u0DAF\u0DCF",
day_short:"\u0D89\u0DBB\u0DD2\u0DAF\u0DCF,\u0DC3\u0DB3\u0DD4\u0DAF\u0DCF,\u0D85\u0D9F.,\u0DB6\u0DAF\u0DCF\u0DAF\u0DCF,\u0DB6\u0DCA\u200D\u0DBB\u0DC4\u0DC3\u0DCA.,\u0DC3\u0DD2\u0D9A\u0DD4.,\u0DC3\u0DD9\u0DB1."
},
print:{
print_desc:"\u0DB8\u0DD4\u0DAF\u0DCA\u200D\u0DBB\u0DAB\u0DBA \u0D9A\u0DBB\u0DB1\u0DC0\u0DCF"
},
preview:{
preview_desc:"\u0DB4\u0DD6\u0DBB\u0DCA\u0DC0 \u0DAF\u0DBB\u0DCA\u0DC1\u0DB1\u0DBA"
},
directionality:{
ltr_desc:"\u0DC0\u0DB8\u0DDA \u0DC3\u0DD2\u0DA7 \u0DAF\u0D9A\u0DD4\u0DAB\u0DA7 \u0DAF\u0DD2\u0DC1\u0DCF\u0DC0",
rtl_desc:"\u0DAF\u0D9A\u0DD4\u0DAB\u0DDA \u0DC3\u0DD2\u0DA7 \u0DC0\u0DB8\u0DA7 \u0DAF\u0DD2\u0DC1\u0DCF\u0DC0"
},
layer:{
insertlayer_desc:"\u0D85\u0DB5\u0DAD\u0DCA \u0DC3\u0DCA\u0DAE\u0DBB\u0DBA\u0D9A\u0DCA \u0D87\u0DAD\u0DD4\u0DC5\u0DAD\u0DCA \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1",
forward_desc:"\u0D89\u0DAF\u0DD2\u0DBB\u0DD2\u0DBA\u0DA7 \u0D9C\u0DD9\u0DB1\u0DBA\u0DB1\u0DCA\u0DB1",
backward_desc:"\u0DB4\u0DC3\u0DD4\u0DB4\u0DC3\u0DA7 \u0D9C\u0DD9\u0DB1\u0DBA\u0DB1\u0DCA\u0DB1",
absolute_desc:"Toggle absolute positioning",
content:"\u0D85\u0DBD\u0DD4\u0DAD\u0DCA \u0DC3\u0DCA\u0DAE\u0DBB\u0DBA\u0D9A\u0DCA..."
},
save:{
save_desc:"\u0DC3\u0DD4\u0DBB\u0D9A\u0DD2\u0DB1\u0DCA\u0DB1",
cancel_desc:"\u0D85\u0DC0\u0DBD\u0D82\u0D9C\u0DD4 \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1"
},
nonbreaking:{
nonbreaking_desc:"Insert non-breaking space character"
},
iespell:{
iespell_desc:"\u0D85\u0D9A\u0DCA\u0DC2\u0DBB \u0DC0\u0DD2\u0DB1\u0DCA\u200D\u0DBA\u0DCF\u0DC3\u0DBA \u0DB4\u0DBB\u0DD3\u0D9A\u0DC2\u0DCF \u0D9A\u0DBB\u0DB1\u0DCA\u0DB1",
download:"ieSpell \u0D85\u0DB1\u0DCF\u0DC0\u0DBB\u0DB1\u0DBA \u0DC0\u0DD6\u0DBA\u0DDA \u0DB1\u0DD0\u0DAD. \u0D94\u0DB6\u0DA7 \u0D91\u0DBA \u0DB4\u0DD2\u0DC4\u0DD2\u0DA7\u0DD4\u0DC0\u0DD3\u0DB8\u0DA7 \u0D85\u0DC0\u0DC1\u0DCA\u200D\u0DBA \u0DAF?"
},
advhr:{
advhr_desc:"Horizontale rule"
},
emotions:{
emotions_desc:"Emotions"
},
searchreplace:{
search_desc:"Find",
replace_desc:"Find/Replace"
},
advimage:{
image_desc:"Insert/edit image"
},
advlink:{
link_desc:"Insert/edit link"
},
xhtmlxtras:{
cite_desc:"Citation",
abbr_desc:"Abbreviation",
acronym_desc:"Acronym",
del_desc:"Deletion",
ins_desc:"Insertion",
attribs_desc:"Insert/Edit Attributes"
},
style:{
desc:"Edit CSS Style"
},
paste:{
paste_text_desc:"Paste as Plain Text",
paste_word_desc:"Paste from Word",
selectall_desc:"Select All",
plaintext_mode_sticky:"Paste is now in plain text mode. Click again to toggle back to regular paste mode. After you paste something you will be returned to regular paste mode.",
plaintext_mode:"Paste is now in plain text mode. Click again to toggle back to regular paste mode."
},
paste_dlg:{
text_title:"Use CTRL+V on your keyboard to paste the text into the window.",
text_linebreaks:"Keep linebreaks",
word_title:"Use CTRL+V on your keyboard to paste the text into the window."
},
table:{
desc:"Inserts a new table",
row_before_desc:"Insert row before",
row_after_desc:"Insert row after",
delete_row_desc:"Delete row",
col_before_desc:"Insert column before",
col_after_desc:"Insert column after",
delete_col_desc:"Remove column",
split_cells_desc:"Split merged table cells",
merge_cells_desc:"Merge table cells",
row_desc:"Table row properties",
cell_desc:"Table cell properties",
props_desc:"Table properties",
paste_row_before_desc:"Paste table row before",
paste_row_after_desc:"Paste table row after",
cut_row_desc:"Cut table row",
copy_row_desc:"Copy table row",
del:"Delete table",
row:"Row",
col:"Column",
cell:"Cell"
},
autosave:{
unload_msg:"The changes you made will be lost if you navigate away from this page.",
restore_content:"Restore auto-saved content.",
warning_message:"If you restore the saved content, you will lose all the content that is currently in the editor.\n\nAre you sure you want to restore the saved content?."
},
fullscreen:{
desc:"Toggle fullscreen mode"
},
media:{
desc:"Insert / edit embedded media",
edit:"Edit embedded media"
},
fullpage:{
desc:"Document properties"
},
template:{
desc:"Insert predefined template content"
},
visualchars:{
desc:"Visual control characters on/off."
},
spellchecker:{
desc:"Toggle spellchecker",
menu:"Spellchecker settings",
ignore_word:"Ignore word",
ignore_words:"Ignore all",
langs:"Languages",
wait:"Please wait...",
sug:"Suggestions",
no_sug:"No suggestions",
no_mpell:"No misspellings found."
},
pagebreak:{
desc:"Insert page break."
},
advlist:{
types:"Types",
def:"Default",
lower_alpha:"Lower alpha",
lower_greek:"Lower greek",
lower_roman:"Lower roman",
upper_alpha:"Upper alpha",
upper_roman:"Upper roman",
circle:"Circle",
disc:"Disc",
square:"Square"
}}});