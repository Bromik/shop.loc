tinyMCE.addI18n('ly.modxlink',{
    link_desc:"Insert/edit link"
});