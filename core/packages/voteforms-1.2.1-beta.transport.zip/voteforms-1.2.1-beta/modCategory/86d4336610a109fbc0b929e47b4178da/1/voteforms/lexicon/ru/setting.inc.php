<?php

$_lang['area_voteforms_main'] = 'Основные';

$_lang['setting_voteforms_assets_url'] = 'Url к файлам фронтенда';
$_lang['setting_voteforms_core_path'] = 'Путь к компоненту';

$_lang['setting_voteforms_frontend_css'] = 'Стили фронтенда';
$_lang['setting_voteforms_frontend_css_desc'] = 'Путь к файлу со стилями. Если вы хотите использовать собственные стили - укажите путь к ним здесь, или очистите параметр и загрузите их вручную через шаблон сайта.';
$_lang['setting_voteforms_frontend_js'] = 'Скрипты фронтенда';
$_lang['setting_voteforms_frontend_js_desc'] = 'Путь к файлу со скриптами. Если вы хотите использовать собственные скрипты - укажите путь к ним здесь, или очистите параметр и загрузите их вручную через шаблон сайта.';