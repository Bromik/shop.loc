<?php
require_once (dirname(dirname(__FILE__)) . '/voteformfield.class.php');
class VoteFormField_mysql extends VoteFormField {}