<?php
class VoteFormField extends xPDOSimpleObject {}