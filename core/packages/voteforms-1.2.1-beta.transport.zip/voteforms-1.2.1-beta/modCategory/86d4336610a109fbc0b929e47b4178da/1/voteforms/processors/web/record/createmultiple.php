<?php
/**
 * Created by PhpStorm.
 * User: me6iaton
 * Date: 22.04.15
 * Time: 13:39
 */

class createmultiple {

}