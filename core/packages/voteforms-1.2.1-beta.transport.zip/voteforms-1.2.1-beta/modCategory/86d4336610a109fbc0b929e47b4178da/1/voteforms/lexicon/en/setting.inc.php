<?php

$_lang['area_voteforms_main'] = 'Main';

$_lang['setting_voteforms_assets_url'] = 'Assets_url';
$_lang['setting_voteforms_core_path'] = 'Core path';

$_lang['setting_voteforms_frontend_css'] = 'Frontend styles';
$_lang['setting_voteforms_frontend_css_desc'] = 'Path to file with styles. If you want to use your own styles - specify them here, or clean this parameter and load them in site template.';
$_lang['setting_voteforms_frontend_js'] = 'Frontend scripts';
$_lang['setting_voteforms_frontend_js_desc'] = 'Path to file with scripts. If you want to use your own sscripts - specify them here, or clean this parameter and load them in site template.';