<?php
require_once (dirname(dirname(__FILE__)) . '/voteformrecord.class.php');
class VoteFormRecord_mysql extends VoteFormRecord {}