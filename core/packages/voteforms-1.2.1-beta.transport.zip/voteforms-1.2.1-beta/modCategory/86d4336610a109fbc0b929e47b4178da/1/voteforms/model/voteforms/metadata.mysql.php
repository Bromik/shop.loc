<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'VoteForm',
    1 => 'VoteFormField',
    2 => 'VoteFormThread',
  ),
  'xPDOObject' => 
  array (
    0 => 'VoteFormRecord',
  ),
);