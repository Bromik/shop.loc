<?php
class VoteFormThread extends xPDOSimpleObject {}