<?php
$_lang['voteforms_prop_id'] = 'Id формы, обязательный параметр';
$_lang['voteforms_prop_thread'] = 'Имя ветки для записи результатов. По умолчанию, "resource-[[*id]]".';
$_lang['voteforms_prop_field'] = 'Id поля - вывести результаты голосования только по этому полю';
$_lang['voteforms_prop_tplRow'] = 'Чанк оформления для каждого поля';
$_lang['voteforms_prop_tplOuter'] = 'Чанк оформления всего содержимого';
$_lang['voteforms_prop_tpl'] = 'Чанк оформления.';
$_lang['voteforms_prop_sortby'] = 'Поле сортировки.';
$_lang['voteforms_prop_sortdir'] = 'Направление сортировки.';
$_lang['voteforms_prop_submit'] = 'Исползовать кнопку отправить в форме';
$_lang['voteforms_prop_form'] = 'Id формы, обязательный параметр';
$_lang['voteforms_prop_resource'] = 'Id ресурса';
$_lang['voteforms_prop_stars'] = 'Выводить виджет с результатами голосования или нет';
