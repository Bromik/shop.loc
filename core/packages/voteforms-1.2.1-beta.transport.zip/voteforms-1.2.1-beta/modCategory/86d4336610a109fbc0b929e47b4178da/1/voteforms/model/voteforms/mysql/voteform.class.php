<?php
require_once (dirname(dirname(__FILE__)) . '/voteform.class.php');
class VoteForm_mysql extends VoteForm {}