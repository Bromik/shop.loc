<?php
class VoteFormRecord extends xPDOObject {}