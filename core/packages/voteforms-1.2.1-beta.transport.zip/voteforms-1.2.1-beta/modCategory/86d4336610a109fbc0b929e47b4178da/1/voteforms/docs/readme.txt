--------------------
VoteForms
--------------------
Author: Anton Mamrashev <me6iaton@gmail.com>
--------------------

Voting system and surveys for MODX Revolution

Donation
http://yasobe.ru/na/voteforms

Feel free to suggest ideas/improvements/bugs on GitHub:
http://github.com/me6iaton/VoteForms/issues