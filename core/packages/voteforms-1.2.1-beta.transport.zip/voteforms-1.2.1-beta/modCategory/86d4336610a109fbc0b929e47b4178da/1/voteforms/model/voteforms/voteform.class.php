<?php
class VoteForm extends xPDOSimpleObject {}