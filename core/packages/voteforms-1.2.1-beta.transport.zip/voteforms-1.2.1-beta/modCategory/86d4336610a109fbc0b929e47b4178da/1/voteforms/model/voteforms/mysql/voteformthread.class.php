<?php
require_once (dirname(dirname(__FILE__)) . '/voteformthread.class.php');
class VoteFormThread_mysql extends VoteFormThread {}