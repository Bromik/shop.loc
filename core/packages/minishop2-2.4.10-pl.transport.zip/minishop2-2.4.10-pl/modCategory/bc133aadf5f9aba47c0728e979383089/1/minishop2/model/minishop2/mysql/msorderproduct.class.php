<?php
require_once (dirname(dirname(__FILE__)) . '/msorderproduct.class.php');
class msOrderProduct_mysql extends msOrderProduct {}